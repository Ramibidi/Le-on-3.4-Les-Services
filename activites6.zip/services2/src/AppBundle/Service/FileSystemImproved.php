<?php

namespace AppBundle\Controller;



use Symfony\Component\Filesystem\Exception\IOExceptionInterface;

use Symfony\Component\Filesystem\Filesystem;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use Symfony\Component\HttpFoundation\Response;

use Symfony\Component\Finder\Finder;

class FileSystemImproved extends Controller
{


    public function __construct()
    {
        $current_dir_path = getcwd();
        try {
            $fs = new Filesystem();
            $new_dir_path = $current_dir_path . "/fsi";
            if (!$fs->exists($new_dir_path)) {
                $fs->mkdir($new_dir_path, 0777);
            } else {
                return new Response('<html><body>fOLDER created!!!</body></html>');
            }
        } catch (IOExceptionInterface $exception) {

            echo "Error creating directory at" . $exception->getPath();
        }
        return new Response('<html><body>Sucessfully!!!</body></html>');
    }

    /**

     * @Route("/create-file/{filename}")

     */
    public function createFile($filename)
    {
        $fs = new Filesystem();
        $current_dir_path = getcwd();
        try {
            $new_file_path = $current_dir_path . "/fsi/" . $filename;
            if (!$fs->exists($new_file_path)) {
                $fs->touch($new_file_path);
                $fs->chmod($new_file_path, 0777);
            } else {
                return new Response('<html><body>Folder  already created!!!</body></html>');
            }
        } catch (IOExceptionInterface $exception) {

            echo "Error creating directory at" . $exception->getPath();
        }
        return new Response('<html><body>Sucessfully!!!</body></html>');
    }



    /**

     * @Route("/delete-file/{filename}")

     */
    public function deleteFile($filename)
    {
        $fs = new Filesystem();
        $current_dir_path = getcwd();
        try {
            $new_file_path = $current_dir_path . "/fsi/" . $filename;
            if ($fs->exists($new_file_path)) {
                //$fs->touch($new_file_path);
                $fs->remove($new_file_path);
            } else {
                return new Response('<html><body>File Deletet!!!</body></html>');
            }
        } catch (IOExceptionInterface $exception) {

            echo "Error creating directory at" . $exception->getPath();
        }
        return new Response('<html><body>Sucessfully!!!</body></html>');
    }


    /**

     * @Route("/write-in-file/{filename}/{text}/{offset?}")

     */
    public function writeInFile($filename, $text, $offset = 0)
    {
        $fs = new Filesystem();
        $current_dir_path = getcwd();
        try {
            $new_file_path = $current_dir_path . "/fsi/" . $filename;
            if ($fs->exists($new_file_path)) {
                $fs->appendToFile($new_file_path, $text);
            } else {
                return new Response('<html><body>Write add!!!</body></html>');
            }
        } catch (IOExceptionInterface $exception) {

            echo "Error creating directory at" . $exception->getPath();
        }
        return new Response('<html><body>Sucessfully!!!</body></html>');
    }



    /**

     * @Route("/read-file/{filename}")

     */
    public function readFile($filename)

    { // init file system

        $fsObject = new Filesystem();

        $current_dir_path = getcwd();

        // read file

        try {

            $file_path = $current_dir_path . "/fsi/" . $filename;

            //   $read = fopen($file_path, "r");

            if ($fsObject->exists($file_path)) {

                $fsObject->chmod($file_path, 0777);

                $finder = new Finder();

                $finder->files()->in($current_dir_path . "/fsi");

                foreach ($finder as $file) {

                    $contents = $file->getContents();

                    print($contents);
                }
            }
        } catch (IOExceptionInterface $exception) {

            echo "Error creating file at" . $exception->getPath();
        }
        return new Response('<html><body></body></html>');
    }
}
