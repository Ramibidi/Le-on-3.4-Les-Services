<?php



namespace AppBundle\Controller;



use Symfony\Component\Filesystem\Exception\IOExceptionInterface;

use Symfony\Component\Filesystem\Filesystem;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use Symfony\Component\HttpFoundation\Response;

class FileController extends Controller



{


    /**

     * @Route("/create/{fileName}", name="createFile")

     */


    public function createFile($fileName)

    {



        $fsObject = new Filesystem();



        $current_dir_path = getcwd();



        try {

            $new_file_path = $current_dir_path . "/$fileName.txt";



            if (!$fsObject->exists($new_file_path)) {

                $fsObject->touch($new_file_path);

                $fsObject->chmod($new_file_path, 0777);

                //$fsObject->dumpFile($new_file_path, "Adding dummy content to bar.txt file.\n");

                //$fsObject->appendToFile($new_file_path, "This should be added to the end of the file.\n");
            }
        } catch (IOExceptionInterface $exception) {

            echo "Error creating file at" . $exception->getPath();
        }



        return new Response('<html><body>File created successfully !!</body></html>');
    }


    /**

     * @Route("/write/{fileName}/{text}")

     */
    public function WriteFile($fileName, $text)
    {
        $fsObject = new Filesystem();

        $current_dir_path = getcwd();


        $new_file_path = $current_dir_path . "/$fileName.txt";

        if ($fsObject->exists($new_file_path)) {


            $fsObject->appendToFile($new_file_path, $text . "\n");
        } else {

            die('File not found');
        }


        return new Response('<html><body>successfully !!</body></html>');
    }








    /**

     * @Route("/copy/{from}/{to}")

     */

    public function copyFile($from, $to)

    {

        $fs = new Filesystem();

        $current_dir_path = getcwd();

        $path_sender = $current_dir_path . "/" . $from;

        $path_reciever = $current_dir_path . "/copied/" . $to;

        try {

            if ($fs->exists($path_sender)) {

                $fs->copy($path_sender, $path_reciever);
            } else {

                return new Response('<html><body>The filename does not exist ! </body></html>');
            }
        } catch (IOExceptionInterface $exception) {

            echo "Error creating file at" . $exception->getPath();
        }

        return new Response('<html><body>The content has been successfully copied ! </body></html>');
    }



    /**

     * @Route("/delete/{filename}")

     */
    public function DeleteFile($filename)
    {
        $fsObject = new Filesystem();

        $current_dir_path = getcwd();


        $new_file_path = $current_dir_path . "/$filename.txt";

        if ($fsObject->exists($new_file_path)) {


            $fsObject->remove($new_file_path);
        } else {

            die('File not found');
        }
        return new Response('<html><body>successfully !!</body></html>');
    }
}
